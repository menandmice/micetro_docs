"""
External authentication module for Micetro.
"""
import json
import sys

try:
    import requests
except ImportError:
    print(
        json.dumps(
            {
                "error": "DependenciesMissing",
                "description": 'Missing dependency "requests"',
            }
        )
    )
    sys.exit(1)

try:
    from urllib.parse import parse_qsl  # Python 3
except:
    from urlparse import parse_qsl  # Python 2

IS_PYTHON_VERSION2 = sys.version_info.major == 2


class MMException(Exception):
    """
    Base exception for errors that we are interested in returning to Central
    """

    def __str__(self):
        return json.dumps(
            {"error": self.__class__.__name__, "description": "\n".join(self.args)}
        )


class InvalidInput(MMException):
    """Raised when input is not according to the provided schema."""

    pass


def parse_data_input(raw_data_str):
    try:
        return json.loads(raw_data_str)
    except ValueError:
        raise InvalidInput("Invalid JSON")


def verify_input(json_input):
    if "arguments" not in json_input:
        raise InvalidInput("Required node 'arguments' missing from JSON input")
    if "config" not in json_input:
        raise InvalidInput("Required node 'config' missing from JSON input")
    if "endpoint" not in json_input:
        raise InvalidInput("Required node 'endpoint' missing from JSON input")

    if json_input["endpoint"] not in {"okta", "microsoft"}:
        raise InvalidInput("Unknown value for 'endpoint' node in JSON input")

    auth_cb_args = dict(parse_qsl(json_input["arguments"]))

    if "code" not in auth_cb_args:
        raise MMException("Missing 'code' from arguments")

    return json_input["endpoint"], auth_cb_args, json_input["config"]


def parse_stdin():
    raw_data_str = sys.stdin.read()
    return parse_data_input(raw_data_str)


# Authenticate with Microsoft Azure AD
# Uses MSAL library from Microsoft: https://github.com/AzureAD/microsoft-authentication-library-for-python
# Ideas mainly borrowed from Python flask example:
# https://github.com/Azure-Samples/ms-identity-python-webapp
def ms_authenticate(args, config):
    try:
        import msal
        from msal.authority import AuthorityBuilder, AZURE_US_GOVERNMENT, AZURE_PUBLIC
    except ImportError:
        print(
            json.dumps(
                {
                    "error": "DependenciesMissing",
                    "description": 'Missing dependency "msal"',
                }
            )
        )
        sys.exit(1)

    tenant_id = config.get("tenant_id", "common")
    authority = AuthorityBuilder(AZURE_PUBLIC, tenant_id)
    client_credential = config["client_credential"]

    app = msal.ConfidentialClientApplication(
        config["client_id"],
        authority=authority,
        client_credential=client_credential,
        app_name="Micetro",
    )
    url = app.get_authorization_request_url(
        config["scope"], redirect_uri=config["redirect_uri"], state=args["state"]
    )

    result = app.acquire_token_by_authorization_code(
        args["code"], config["scope"], redirect_uri=config["redirect_uri"]
    )

    if "error" in result:
        message = result.get("error_description", "")
        raise MMException("Error authenticating: " + message)

    access_token = result.get("access_token")
    ui_res = result.get("id_token_claims")

    graph_endpoint = config.get(
        "groups_uri",
        "https://graph.microsoft.com/v1.0/me/transitiveMemberOf/microsoft.graph.group?$select=displayName,id",
    )
    groups_res = requests.get(
        graph_endpoint, headers={"Authorization": "Bearer {}".format(access_token)}
    ).json()

    # If we get group ids as part of the authentication results we should
    # filter by those since it is possible for admins to limit them in
    # the application config in Azure AD.
    should_filter_groups = "groups" in ui_res
    group_ids = ui_res.get("groups", [])

    group_names = []
    for group in groups_res.get("value", []):
        if not should_filter_groups or group.get("id") in group_ids:
            group_names.append(group.get("displayName"))

    user_details = {
        "loginName": ui_res.get("preferred_username", ""),
        "fullName": ui_res.get("name", ""),
        "externalID": ui_res.get("sub", ""),
        "email": ui_res.get("preferred_username", ""),
        "groups": group_names,
        "authenticator": "Microsoft",
        # "_group_ids": group_ids,
        # "_graph_groups": groups_res,
    }
    return user_details


# Authenticate with Okta
# Uses okta_jwt_verifier: https://github.com/okta/okta-jwt-verifier-python
# Code mainly from:
# https://github.com/okta/samples-python-flask
def okta_authenticate(args, config):
    import asyncio

    try:
        import okta_jwt_verifier
    except ImportError:
        print(
            json.dumps(
                {
                    "error": "DependenciesMissing",
                    "description": 'Missing dependency "okta_jwt_verifier"',
                }
            )
        )
        sys.exit(1)

    loop = asyncio.new_event_loop()
    if sys.version_info < (3, 8):
        asyncio.set_event_loop(loop)

    def is_access_token_valid(token, issuer):
        jwt_verifier = okta_jwt_verifier.AccessTokenVerifier(
            issuer=issuer, audience="api://default"
        )
        try:
            loop.run_until_complete(jwt_verifier.verify(token))
            return True
        except Exception:
            return False

    def is_id_token_valid(token, issuer, client_id):
        jwt_verifier = okta_jwt_verifier.IDTokenVerifier(
            issuer=issuer, client_id=client_id, audience="api://default"
        )
        try:
            loop.run_until_complete(jwt_verifier.verify(token))
            return True
        except Exception:
            return False

    code = args["code"]

    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    query_params = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": config["redirect_uri"],
    }
    query_params = requests.compat.urlencode(query_params)
    exchange = requests.post(
        config["token_uri"],
        headers=headers,
        data=query_params,
        auth=(config["client_id"], config["client_secret"]),
    ).json()

    if "errorCode" in exchange:
        message = exchange.get("errorSummary", "")
        raise MMException("Error authenticating: " + message)

    # Get tokens and validate
    if "token_type" not in exchange or exchange["token_type"] != "Bearer":
        raise MMException("Unsupported token type. Should be 'Bearer'.")
    if "access_token" not in exchange:
        raise MMException("Missing access_token.")
    if "id_token" not in exchange:
        raise MMException("Missing id_token.")

    access_token = exchange["access_token"]
    id_token = exchange["id_token"]

    if not is_access_token_valid(access_token, config["issuer"]):
        raise MMException("Access token is invalid")

    if not is_id_token_valid(id_token, config["issuer"], config["client_id"]):
        raise MMException("ID token is invalid")

    # Authorization flow successful, get userinfo and login user
    ui_res = requests.get(
        config["userinfo_uri"],
        headers={"Authorization": "Bearer {}".format(access_token)},
    ).json()

    user_details = {
        "loginName": ui_res.get("preferred_username", ""),
        "fullName": ui_res.get("name", ""),
        "externalID": ui_res.get("sub", ""),
        "email": ui_res.get("email", ""),
        "idToken": id_token,
        # Assumes an ID Token Claim has been created with the name "groups".
        "groups": ui_res.get("groups", []),
        "authenticator": "Okta",
    }

    return user_details


def main():
    try:
        json_input = parse_stdin()
        endpoint, arguments, config = verify_input(json_input)

        user_details = {}
        if endpoint == "microsoft":
            user_details = ms_authenticate(arguments, config)
        else:
            user_details = okta_authenticate(arguments, config)

        output = json.dumps(user_details, ensure_ascii=False)
        if IS_PYTHON_VERSION2:
            print(output.encode("iso-8859-1", "ignore"))
        else:
            print(output)
    except Exception as e:
        print(e)
        sys.exit(1)


if __name__ == "__main__":
    main()
